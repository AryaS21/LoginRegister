package com.example.loginandregister;

public interface ApiInterface {
}
